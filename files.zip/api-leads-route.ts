import { NextRequest, NextResponse } from 'next/server'

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface LeadPayload {
  // Step 1: Property
  address: string
  city: string
  state: string
  zip: string
  // Step 2: Details
  condition: string
  timeline: string
  // Step 3: Contact
  firstName: string
  lastName: string
  phone: string
  email: string
  // Compliance
  tcpaConsent: boolean
  tcpaTimestamp: string
  // Anti-spam
  honeypot?: string
  // Meta
  source?: string
  landingPage?: string
  utmSource?: string
  utmMedium?: string
  utmCampaign?: string
  utmTerm?: string
  utmContent?: string
}

/* ------------------------------------------------------------------ */
/*  Validation helpers                                                 */
/* ------------------------------------------------------------------ */

function validatePhone(phone: string): boolean {
  const cleaned = phone.replace(/\D/g, '')
  return cleaned.length === 10 || cleaned.length === 11
}

function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

function validateZip(zip: string): boolean {
  return /^\d{5}(-\d{4})?$/.test(zip)
}

function sanitize(str: string): string {
  return str.trim().replace(/<[^>]*>/g, '').substring(0, 500)
}

/* ------------------------------------------------------------------ */
/*  Rate limiting (in-memory, resets on server restart)                */
/* ------------------------------------------------------------------ */

const rateLimitMap = new Map<string, { count: number; resetAt: number }>()
const RATE_LIMIT_MAX = 5 // max submissions per window
const RATE_LIMIT_WINDOW = 60 * 60 * 1000 // 1 hour

function isRateLimited(ip: string): boolean {
  const now = Date.now()
  const entry = rateLimitMap.get(ip)

  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW })
    return false
  }

  entry.count++
  if (entry.count > RATE_LIMIT_MAX) {
    return true
  }

  return false
}

/* ------------------------------------------------------------------ */
/*  POST handler                                                       */
/* ------------------------------------------------------------------ */

export async function POST(request: NextRequest) {
  try {
    const ip =
      request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      request.headers.get('x-real-ip') ||
      'unknown'

    // Rate limiting
    if (isRateLimited(ip)) {
      return NextResponse.json(
        { error: 'Too many submissions. Please try again later.' },
        { status: 429 }
      )
    }

    const body: LeadPayload = await request.json()

    // ---- Honeypot check ----
    if (body.honeypot) {
      // Bot filled the hidden field — silently accept but don't process
      console.log(`[SPAM BLOCKED] Honeypot triggered from IP: ${ip}`)
      return NextResponse.json({ success: true, message: 'Thank you! We will be in touch.' })
    }

    // ---- Required field validation ----
    const errors: string[] = []

    if (!body.address || body.address.trim().length < 3) errors.push('Address is required')
    if (!body.city || body.city.trim().length < 2) errors.push('City is required')
    if (!body.state || !['WA', 'ID'].includes(body.state)) errors.push('State must be WA or ID')
    if (!body.zip || !validateZip(body.zip)) errors.push('Valid ZIP code is required')
    if (!body.condition) errors.push('Property condition is required')
    if (!body.timeline) errors.push('Timeline is required')
    if (!body.firstName || body.firstName.trim().length < 1) errors.push('First name is required')
    if (!body.lastName || body.lastName.trim().length < 1) errors.push('Last name is required')
    if (!body.phone || !validatePhone(body.phone)) errors.push('Valid phone number is required')
    if (!body.email || !validateEmail(body.email)) errors.push('Valid email is required')

    // ---- TCPA consent check (CRITICAL) ----
    if (!body.tcpaConsent) {
      errors.push('TCPA consent is required')
    }

    if (errors.length > 0) {
      return NextResponse.json({ error: 'Validation failed', details: errors }, { status: 400 })
    }

    // ---- Sanitize all fields ----
    const lead = {
      address: sanitize(body.address),
      city: sanitize(body.city),
      state: body.state,
      zip: sanitize(body.zip),
      condition: sanitize(body.condition),
      timeline: sanitize(body.timeline),
      firstName: sanitize(body.firstName),
      lastName: sanitize(body.lastName),
      phone: body.phone.replace(/\D/g, '').substring(0, 11),
      email: sanitize(body.email).toLowerCase(),
      // TCPA immutable audit log
      tcpa: {
        consented: true,
        consentTimestamp: body.tcpaTimestamp || new Date().toISOString(),
        consentIP: ip,
        consentUserAgent: request.headers.get('user-agent') || 'unknown',
        consentText:
          'By checking this box, you consent to receive calls, texts, and emails from Dominion Homes, LLC at the number and email provided, including by autodialer and prerecorded messages, for the purpose of discussing the sale of your property. Consent is not a condition of purchase. Message and data rates may apply. Reply STOP to opt out.',
      },
      // UTM & attribution
      source: sanitize(body.source || 'website'),
      landingPage: sanitize(body.landingPage || '/'),
      utm: {
        source: sanitize(body.utmSource || ''),
        medium: sanitize(body.utmMedium || ''),
        campaign: sanitize(body.utmCampaign || ''),
        term: sanitize(body.utmTerm || ''),
        content: sanitize(body.utmContent || ''),
      },
      // Metadata
      submittedAt: new Date().toISOString(),
      ip,
    }

    // ---- Log the lead (console for now) ----
    console.log('[NEW LEAD]', JSON.stringify(lead, null, 2))

    // ---- Push to Sentinel CRM ----
    // TODO: Replace with your actual Sentinel webhook URL
    const SENTINEL_WEBHOOK_URL = process.env.SENTINEL_WEBHOOK_URL

    if (SENTINEL_WEBHOOK_URL) {
      try {
        const sentinelResponse = await fetch(SENTINEL_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...lead,
            source_system: 'dominionhomedeals.com',
            pipeline_stage: 'new_lead',
            priority: body.timeline === 'ASAP' ? 'high' : body.timeline === 'Soon' ? 'medium' : 'normal',
          }),
        })

        if (!sentinelResponse.ok) {
          console.error('[SENTINEL ERROR]', await sentinelResponse.text())
        } else {
          console.log('[SENTINEL] Lead pushed successfully')
        }
      } catch (sentinelErr) {
        console.error('[SENTINEL ERROR]', sentinelErr)
        // Don't fail the lead submission if Sentinel is down
      }
    }

    // ---- Send notification email (optional) ----
    // TODO: Add email notification via Resend, SendGrid, etc.

    return NextResponse.json({
      success: true,
      message: 'Thank you! One of our team members will reach out within 24 hours.',
      leadId: `DH-${Date.now()}`,
    })
  } catch (err) {
    console.error('[LEAD API ERROR]', err)
    return NextResponse.json(
      { error: 'Something went wrong. Please call us at 208-625-8078.' },
      { status: 500 }
    )
  }
}

/* ------------------------------------------------------------------ */
/*  GET handler (health check)                                         */
/* ------------------------------------------------------------------ */

export async function GET() {
  return NextResponse.json({ status: 'ok', endpoint: '/api/leads', method: 'POST' })
}
